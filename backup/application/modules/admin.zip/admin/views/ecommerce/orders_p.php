<style>
            .new{
            background-color: #505cff;
            color:white;
            display: grid;
            padding: 13px;
            
          }
          .Strated_Processeing{
            background-color: #ff4848;
            color:white;
            display: grid;
            padding: 13px;
            
          }
          .complet{
            background-color: #00d67d;
            color:white;
            display: grid;
            padding: 13px;
            
          }
          .b1{
            width: 94px;
    height: 23px;
    background-color: #505cff;
    color: white;
          }
          .b1:hover{
     width: 94px;
    height: 23px;
    background-color: #3e48d1;
    color: white;
          }


          .b2{
            width: 94px;
    height: 23px;
    background-color: #ff4848;
    color: white;
          }
          .b2:hover{
     width: 94px;
    height: 23px;
    background-color: #d13838;
    color: white;
          }
          .b3{
            width: 94px;
    height: 23px;
    background-color: #00d67d;
    color: white;
          }
          .b3:hover{
     width: 94px;
    height: 23px;
    background-color: #1e8929;
    color: white;
          }
          
          .r{
            width: 94px;
    height: 73px;
    background-color: red;
    color: white;
    display: grid;
    
}
.main_c{

  font-size: 15px;
  color: black;
  border: 2px solid #000;
}
.table-bordered>tbody>tr>td, 
.table-bordered>tbody>tr>th, 
.table-bordered>tfoot>tr>td, 
.table-bordered>tfoot>tr>th, 
.table-bordered>thead>tr>td, 
.table-bordered>thead>tr>th {
    border: 2px solid #000;
}
h5{font-family: inherit;
    font-weight: 600;
    line-height: 1.1;
    color: black;
}

</style>
<link href="<?= base_url('assets/css/bootstrap-toggle.min.css') ?>" rel="stylesheet">
<div>
    <h1><img src="<?= base_url('assets/imgs/orders.png') ?>" class="header-img" style="margin-top:-2px;"> ORDERS VIA PRESCRIPTION </h1>
    
</div>
<?php
  // Create database connection
  $db = mysqli_connect("localhost", "chemedsorg_chemedsorg", "gfki-W}bB@3v", "chemedsorg_shop");
  $id = "";

  $result = mysqli_query($db, "SELECT `id`, `full_name`, `phone`, `address`, `image`, `status`, `sub_time` FROM `orders_clients_by_p`");
  
  


  
  ?>
</head>
<body>

<div class="table-responsive">        
<table class="table table-condensed table-bordered table-striped" >
<thead>
<tr class="danger">
<th>Order</th>
<th>Id</th>
    <th>Name</th>
    <th>Phone</th>
    <th>Address</th>
    <th>Image</th>
    <th>Order on</th>
    <th>Status</th>
  </tr>  </thead>
<tbody>

  <?php    foreach ($result as $row) {
      if ($row['status'] == 0) {
          $class = 'new';
          $type = 'New';
      }
      if ($row['status'] == 1) {
          $class = 'Strated_Processeing';
          $type = 'Strated Processeing';
      }
      if ($row['status'] == 2) {
          $class = 'complet';
          $type = 'Completed';
      } ?>   

			<tr class="">
	
				<td><div class="<?= $class ?>"><h5><?php echo $type; ?></h5></div></td>
        <td><h5><?= $row["id"]; ?></h5></td>
				<td><h5><?= $row["full_name"]; ?></h5></td>
				<td><h5><?= $row["phone"]; ?></h5></td>
				<td><h5><?= $row["address"]; ?></h5></td>
        <td><?php echo "<img style='width:70px;' src='http://localhost/chemeds/attachments/shop_images/". htmlspecialchars ($row['image'])."' >";?></td>
        <td><h5><?= $row["sub_time"]; ?></h5></td>              
        <td><div class="<?= $class ?>">
        <?=$id = $row["id"]; ?>
        <form method="POST" enctype="multipart/form-data"  <?= base_url('orders_p.php') ?> >
        <button class="b1" type="submit" name="upload1" >New</button><br>
        <button class="b2" type="submit" name="upload2" >Strated Processeing</button><br>
        <button class="b3" type="submit" name="upload3" >completed</button><br>
      
        </form>
        </td>   
    
			</tr>
		
      
		<?php }?>
      </tbody>
	</table>
<?php   if (isset($_POST['upload1'])) {
    $sql = "UPDATE `orders_clients_by_p` SET `status`='0' WHERE id = $id";   
         mysqli_query($db, $sql);
    }
  if (isset($_POST['upload2'])) {
      $sql = "UPDATE `orders_clients_by_p` SET `status`='1' WHERE id = $id";   
           mysqli_query($db, $sql);
    }
    if (isset($_POST['upload3'])) {
      $sql = "UPDATE `orders_clients_by_p` SET `status`='2' WHERE id = $id";   
           mysqli_query($db, $sql);
    }

  
  ?>
</div>



